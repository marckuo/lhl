$(document).ready(function(){
  $('#hide_photos').click(function(){
    $('img').toggle();
  });
  $('.recipe_item').click(function(){
    $(this).toggle();
  });
  $('#recipe_button').click(function(){
    $('.recipe_item').show();
  });

});
